﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace yrtotmsyn
{
    public partial class odemeForm : Form
    {
        public odemeForm()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void odemeForm_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet2.Borclar' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.borclarTableAdapter.Fill(this.yurtOtomasyonDataSet2.Borclar);

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen;
            string id, kalan;
            secilen = dataGridView1.SelectedCells[0].RowIndex;
            id = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            kalan = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            oogrid.Text = id;
            kklnborc.Text = kalan;

        }

        private void OdemeAl_Click(object sender, EventArgs e)
        {
            //ödenen tutarın kalandan çıkarılması
            int odenen;
            int kalan;
            int sonBorc;
            odenen = Convert.ToInt16(odborc.Text);
            kalan = Convert.ToInt16(kklnborc.Text);
            sonBorc = kalan - odenen;
            kklnborc.Text = sonBorc.ToString();

           
            //yeni tutar vt kaydet
            SqlCommand kmt = new SqlCommand("update Borclar set Ogr_kalan_borc =@p1 where Ogr_id=@p2", con.conn());
            kmt.Parameters.AddWithValue("@p2", oogrid.Text);
            kmt.Parameters.AddWithValue("@p1", kklnborc.Text);
            kmt.ExecuteNonQuery();
         
            con.conn().Close();
            MessageBox.Show("Borç Ödendi");
            this.borclarTableAdapter.Fill(this.yurtOtomasyonDataSet2.Borclar);

        }
    }
}
