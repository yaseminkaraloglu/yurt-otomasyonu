﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace yrtotmsyn
{
    public partial class Giderler : Form
    {
        public Giderler()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ogr_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void Giderler_Load(object sender, EventArgs e)
        {

        }

        private void Kaydet_Click(object sender, EventArgs e)
        {

            try
            {
                SqlCommand kmt = new SqlCommand("insert into Gider (Elektrik,Su,Dogalgaz,Internet,Gıda,Personel,Diger) values(@p1,@p2,@p3,@p4,@p5,@p6,@p7) ", con.conn());
                kmt.Parameters.AddWithValue("@p1", Elektrik.Text);
                kmt.Parameters.AddWithValue("@p2", Su.Text);
                kmt.Parameters.AddWithValue("@p3", Dgaz.Text);
                kmt.Parameters.AddWithValue("@p4", Net.Text);
                kmt.Parameters.AddWithValue("@p5", Gd.Text);
                kmt.Parameters.AddWithValue("@p6", Pers.Text);
                kmt.Parameters.AddWithValue("@p7", Dgr.Text);
                kmt.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Kayıt Eklendi");
            }
            catch (Exception)
            {
                MessageBox.Show("Hata!!!  Kayıt Eklenemedi");

            }




        }
    }
}
