﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace yrtotmsyn
{
    public partial class GiderList : Form
    {
        public GiderList()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void GiderList_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet4.Gider' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.giderTableAdapter.Fill(this.yurtOtomasyonDataSet4.Gider);

        }
        int sec;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            GiderGuncelle gg = new GiderGuncelle();
            sec = dataGridView1.SelectedCells[0].RowIndex;
            gg.id = dataGridView1.Rows[sec].Cells[0].Value.ToString();
            gg.elektrik = dataGridView1.Rows[sec].Cells[1].Value.ToString();
            gg.su = dataGridView1.Rows[sec].Cells[2].Value.ToString();
            gg.dgaz = dataGridView1.Rows[sec].Cells[3].Value.ToString();
            gg.net = dataGridView1.Rows[sec].Cells[4].Value.ToString();
            gg.gida = dataGridView1.Rows[sec].Cells[5].Value.ToString();
            gg.pers = dataGridView1.Rows[sec].Cells[6].Value.ToString();
            gg.diger = dataGridView1.Rows[sec].Cells[7].Value.ToString();

            gg.Show();
            this.giderTableAdapter.Fill(this.yurtOtomasyonDataSet4.Gider);

        }
    }
}
