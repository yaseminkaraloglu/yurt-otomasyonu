﻿
namespace yrtotmsyn
{
    partial class GiderGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Güncelle = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Dgr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Pers = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Gd = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Net = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Dgaz = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Su = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Elektrik = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.odmid = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Güncelle
            // 
            this.Güncelle.BackColor = System.Drawing.SystemColors.Info;
            this.Güncelle.Location = new System.Drawing.Point(155, 318);
            this.Güncelle.Name = "Güncelle";
            this.Güncelle.Size = new System.Drawing.Size(91, 31);
            this.Güncelle.TabIndex = 77;
            this.Güncelle.Text = "Güncelle";
            this.Güncelle.UseVisualStyleBackColor = false;
            this.Güncelle.Click += new System.EventHandler(this.Güncelle_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 286);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 76;
            this.label8.Text = "Diğer:";
            // 
            // Dgr
            // 
            this.Dgr.BackColor = System.Drawing.SystemColors.Info;
            this.Dgr.Location = new System.Drawing.Point(127, 279);
            this.Dgr.Name = "Dgr";
            this.Dgr.Size = new System.Drawing.Size(159, 20);
            this.Dgr.TabIndex = 75;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 74;
            // 
            // Pers
            // 
            this.Pers.BackColor = System.Drawing.SystemColors.Info;
            this.Pers.Location = new System.Drawing.Point(127, 249);
            this.Pers.Name = "Pers";
            this.Pers.Size = new System.Drawing.Size(159, 20);
            this.Pers.TabIndex = 73;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 72;
            this.label6.Text = "Gıda:";
            // 
            // Gd
            // 
            this.Gd.BackColor = System.Drawing.SystemColors.Info;
            this.Gd.Location = new System.Drawing.Point(127, 213);
            this.Gd.Name = "Gd";
            this.Gd.Size = new System.Drawing.Size(159, 20);
            this.Gd.TabIndex = 71;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 70;
            this.label7.Text = "İnternet:";
            // 
            // Net
            // 
            this.Net.BackColor = System.Drawing.SystemColors.Info;
            this.Net.Location = new System.Drawing.Point(127, 176);
            this.Net.Name = "Net";
            this.Net.Size = new System.Drawing.Size(159, 20);
            this.Net.TabIndex = 69;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 252);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 68;
            this.label3.Text = "Personel:";
            // 
            // Dgaz
            // 
            this.Dgaz.BackColor = System.Drawing.SystemColors.Info;
            this.Dgaz.Location = new System.Drawing.Point(127, 140);
            this.Dgaz.Name = "Dgaz";
            this.Dgaz.Size = new System.Drawing.Size(159, 20);
            this.Dgaz.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 66;
            this.label4.Text = "Doğalgaz:";
            // 
            // Su
            // 
            this.Su.BackColor = System.Drawing.SystemColors.Info;
            this.Su.Location = new System.Drawing.Point(127, 110);
            this.Su.Name = "Su";
            this.Su.Size = new System.Drawing.Size(159, 20);
            this.Su.TabIndex = 65;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 64;
            this.label2.Text = "Su:";
            // 
            // Elektrik
            // 
            this.Elektrik.BackColor = System.Drawing.SystemColors.Info;
            this.Elektrik.Location = new System.Drawing.Point(127, 74);
            this.Elektrik.Name = "Elektrik";
            this.Elektrik.Size = new System.Drawing.Size(159, 20);
            this.Elektrik.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 62;
            this.label1.Text = "Elektrik:";
            // 
            // odmid
            // 
            this.odmid.BackColor = System.Drawing.SystemColors.Info;
            this.odmid.Location = new System.Drawing.Point(127, 48);
            this.odmid.Name = "odmid";
            this.odmid.Size = new System.Drawing.Size(159, 20);
            this.odmid.TabIndex = 79;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 78;
            this.label9.Text = "Ödeme İd:";
            // 
            // GiderGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 408);
            this.Controls.Add(this.odmid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Güncelle);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Dgr);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Pers);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Gd);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Net);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Dgaz);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Su);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Elektrik);
            this.Controls.Add(this.label1);
            this.Name = "GiderGuncelle";
            this.Text = "GiderGüncelle";
            this.Load += new System.EventHandler(this.GiderGüncelle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Güncelle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Dgr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Pers;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Gd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Net;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Dgaz;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Su;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Elektrik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox odmid;
        private System.Windows.Forms.Label label9;
    }
}