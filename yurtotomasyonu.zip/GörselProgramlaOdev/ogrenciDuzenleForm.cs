﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace yrtotmsyn
{
    public partial class ogrenciDuzenleForm : Form
    {
        public ogrenciDuzenleForm()
        {
            InitializeComponent();
        }

        public string id,ad,syd,tc,tel,dt,blm,mail,odano,veliAdSyd,veliTel,veliAdrs;

        private void sill_Click(object sender, EventArgs e)
        {
                SqlCommand kmt = new SqlCommand("delete from ogrenci where Ogr_id=@a", con.conn());
            kmt.Parameters.AddWithValue("@a", ogr_id.Text);
            kmt.ExecuteNonQuery();
            con.conn().Close();
            MessageBox.Show("Öğrenci Silme Başarılı");
            SqlCommand kmtt = new SqlCommand("update odalar set Oda_aktif=Oda_aktif-1 where Oda_no=@a", con.conn());
            kmtt.Parameters.AddWithValue("@a", Oda_no.Text);

            kmtt.ExecuteNonQuery();
            con.conn().Close();

        }

        SqlBaglanti con = new SqlBaglanti();
        private void Güncelle_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand kmt = new SqlCommand("update ogrenci set Ogr_ad=@p1,Ogr_syd=@p2,Tc_no=@p3,Telefon_no=@p4,Dogum_tarih=@p5,Bolum=@p6,Mail=@p7,Oda_no=@p8,Veli_ad_soyad=@p9,Veli_telefon_numara=@p10,Veli_adres=@p11 where Ogr_id=@a1", con.conn());
                kmt.Parameters.AddWithValue("@a1", ogr_id.Text);
                kmt.Parameters.AddWithValue("@p1", Ogr_ad.Text);
                kmt.Parameters.AddWithValue("@p2", Ogr_syd.Text);
                kmt.Parameters.AddWithValue("@p3", Ogr_tc.Text);
                kmt.Parameters.AddWithValue("@p4", Ogr_tel.Text);
                kmt.Parameters.AddWithValue("@p5", Ogr_dt.Text);
                kmt.Parameters.AddWithValue("@p6", Ogr_blm.Text);
                kmt.Parameters.AddWithValue("@p7", Ogr_mail.Text);
                kmt.Parameters.AddWithValue("@p8", Oda_no.Text);
                kmt.Parameters.AddWithValue("@p9", Veli_ad_syd.Text);
                kmt.Parameters.AddWithValue("@p10", Veli_tel.Text);
                kmt.Parameters.AddWithValue("@p11", Veli_adrs.Text);
                kmt.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Güncelleme Başarılı");

            }
            catch (Exception)
            {
                MessageBox.Show("Hata!!!! Tekrar Deneyiniz");
            }
       

        }

        private void ogrenciDuzenleForm_Load(object sender, EventArgs e)
        {
            ogr_id.Text = id;
           
            Ogr_ad.Text = ad; 
            Ogr_syd.Text =syd;
           Ogr_tc.Text = tc;
           Ogr_tel.Text = tel;
          Ogr_dt.Text = dt;
           Ogr_blm.Text = blm;
           Ogr_mail.Text = mail;
           Oda_no.Text = odano;
           Veli_ad_syd.Text = veliAdSyd;
           Veli_tel.Text = veliTel;
           Veli_adrs.Text = veliAdrs;
           
        }
    }
}
