﻿
namespace yrtotmsyn
{
    partial class Ogr_kyt_frm
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Ogr_ad = new System.Windows.Forms.TextBox();
            this.Ogr_tc = new System.Windows.Forms.MaskedTextBox();
            this.Ogr_syd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Ogr_tel = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Ogr_dt = new System.Windows.Forms.MaskedTextBox();
            this.Ogr_blm = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Ogr_mail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Oda_no = new System.Windows.Forms.ComboBox();
            this.Veli_adrs = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Veli_ad_syd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Veli_tel = new System.Windows.Forms.MaskedTextBox();
            this.Kaydet = new System.Windows.Forms.Button();
            this.ogrid = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Öğrenci Ad:";
            // 
            // Ogr_ad
            // 
            this.Ogr_ad.Location = new System.Drawing.Point(130, 18);
            this.Ogr_ad.Name = "Ogr_ad";
            this.Ogr_ad.Size = new System.Drawing.Size(159, 20);
            this.Ogr_ad.TabIndex = 1;
            // 
            // Ogr_tc
            // 
            this.Ogr_tc.Location = new System.Drawing.Point(130, 101);
            this.Ogr_tc.Mask = "00000000000";
            this.Ogr_tc.Name = "Ogr_tc";
            this.Ogr_tc.Size = new System.Drawing.Size(158, 20);
            this.Ogr_tc.TabIndex = 3;
            this.Ogr_tc.ValidatingType = typeof(int);
            // 
            // Ogr_syd
            // 
            this.Ogr_syd.Location = new System.Drawing.Point(130, 65);
            this.Ogr_syd.Name = "Ogr_syd";
            this.Ogr_syd.Size = new System.Drawing.Size(158, 20);
            this.Ogr_syd.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Öğrenci Soyad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Öğrenci TC:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Öğrenci Telefon:";
            // 
            // Ogr_tel
            // 
            this.Ogr_tel.Location = new System.Drawing.Point(130, 140);
            this.Ogr_tel.Mask = "(999) 000-0000";
            this.Ogr_tel.Name = "Ogr_tel";
            this.Ogr_tel.Size = new System.Drawing.Size(158, 20);
            this.Ogr_tel.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Öğrenci Doğum Tarihi:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Ogr_dt
            // 
            this.Ogr_dt.Location = new System.Drawing.Point(130, 177);
            this.Ogr_dt.Mask = "00/00/0000";
            this.Ogr_dt.Name = "Ogr_dt";
            this.Ogr_dt.Size = new System.Drawing.Size(159, 20);
            this.Ogr_dt.TabIndex = 9;
            this.Ogr_dt.ValidatingType = typeof(System.DateTime);
            this.Ogr_dt.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // Ogr_blm
            // 
            this.Ogr_blm.FormattingEnabled = true;
            this.Ogr_blm.Location = new System.Drawing.Point(130, 213);
            this.Ogr_blm.Name = "Ogr_blm";
            this.Ogr_blm.Size = new System.Drawing.Size(158, 21);
            this.Ogr_blm.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Öğrenci Bölüm:";
            // 
            // Ogr_mail
            // 
            this.Ogr_mail.Location = new System.Drawing.Point(130, 254);
            this.Ogr_mail.Name = "Ogr_mail";
            this.Ogr_mail.Size = new System.Drawing.Size(158, 20);
            this.Ogr_mail.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 261);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Öğrenci Mail:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 300);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Oda No:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // Oda_no
            // 
            this.Oda_no.FormattingEnabled = true;
            this.Oda_no.Location = new System.Drawing.Point(130, 297);
            this.Oda_no.Name = "Oda_no";
            this.Oda_no.Size = new System.Drawing.Size(158, 21);
            this.Oda_no.TabIndex = 15;
            this.Oda_no.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Veli_adrs
            // 
            this.Veli_adrs.Location = new System.Drawing.Point(130, 401);
            this.Veli_adrs.Name = "Veli_adrs";
            this.Veli_adrs.Size = new System.Drawing.Size(158, 20);
            this.Veli_adrs.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 404);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Veli Adres:";
            // 
            // Veli_ad_syd
            // 
            this.Veli_ad_syd.Location = new System.Drawing.Point(130, 332);
            this.Veli_ad_syd.Name = "Veli_ad_syd";
            this.Veli_ad_syd.Size = new System.Drawing.Size(158, 20);
            this.Veli_ad_syd.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 335);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Veli Ad Soyad:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 369);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Veli Telefon:";
            // 
            // Veli_tel
            // 
            this.Veli_tel.Location = new System.Drawing.Point(130, 362);
            this.Veli_tel.Mask = "(999) 000-0000";
            this.Veli_tel.Name = "Veli_tel";
            this.Veli_tel.Size = new System.Drawing.Size(158, 20);
            this.Veli_tel.TabIndex = 21;
            // 
            // Kaydet
            // 
            this.Kaydet.BackColor = System.Drawing.SystemColors.Info;
            this.Kaydet.Location = new System.Drawing.Point(197, 446);
            this.Kaydet.Name = "Kaydet";
            this.Kaydet.Size = new System.Drawing.Size(91, 31);
            this.Kaydet.TabIndex = 23;
            this.Kaydet.Text = "Kaydet";
            this.Kaydet.UseVisualStyleBackColor = false;
            this.Kaydet.Click += new System.EventHandler(this.Kaydet_Click);
            // 
            // ogrid
            // 
            this.ogrid.AutoSize = true;
            this.ogrid.Location = new System.Drawing.Point(31, 434);
            this.ogrid.Name = "ogrid";
            this.ogrid.Size = new System.Drawing.Size(10, 13);
            this.ogrid.TabIndex = 24;
            this.ogrid.Text = " ";
            this.ogrid.Visible = false;
            // 
            // Ogr_kyt_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(527, 502);
            this.Controls.Add(this.ogrid);
            this.Controls.Add(this.Kaydet);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Veli_tel);
            this.Controls.Add(this.Veli_adrs);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Veli_ad_syd);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Oda_no);
            this.Controls.Add(this.Ogr_mail);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Ogr_blm);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Ogr_dt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Ogr_tel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Ogr_syd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Ogr_tc);
            this.Controls.Add(this.Ogr_ad);
            this.Controls.Add(this.label1);
            this.Name = "Ogr_kyt_frm";
            this.Text = "Ogrenci_kayit";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Ogr_ad;
        private System.Windows.Forms.MaskedTextBox Ogr_tc;
        private System.Windows.Forms.TextBox Ogr_syd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox Ogr_tel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox Ogr_dt;
        private System.Windows.Forms.ComboBox Ogr_blm;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Ogr_mail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Oda_no;
        private System.Windows.Forms.TextBox Veli_adrs;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Veli_ad_syd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox Veli_tel;
        private System.Windows.Forms.Button Kaydet;
        private System.Windows.Forms.Label ogrid;
    }
}

