﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace yrtotmsyn
{
    public partial class adminGiris : Form
    {
        public adminGiris()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();
        private void adminGiris_Load(object sender, EventArgs e)
        {

        }

        private void giris_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("select * from Admin where Yonetici_ad=@a and Yonetici_sifre=@b", con.conn());

            kmt.Parameters.AddWithValue("@a", kullaniciAd.Text);
            kmt.Parameters.AddWithValue("@b", sifre.Text);
            SqlDataReader read = kmt.ExecuteReader();
            if (read.Read())
            {
                AnaForm go = new AnaForm();
                go.Show();
                this.Hide();


            }
            else
            {
                MessageBox.Show("!!! Hatalı Kullanıcı Adı veya Şifre !!!");
                kullaniciAd.Clear();
                sifre.Clear();
                kullaniciAd.Focus();
            }

            con.conn().Close();


        }
    }
}
