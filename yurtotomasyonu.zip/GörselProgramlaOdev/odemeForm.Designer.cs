﻿
namespace yrtotmsyn
{
    partial class odemeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.oogrid = new System.Windows.Forms.TextBox();
            this.kklnborc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.odborc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.OdemeAl = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.yurtOtomasyonDataSet2 = new yrtotmsyn.YurtOtomasyonDataSet2();
            this.borclarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.borclarTableAdapter = new yrtotmsyn.YurtOtomasyonDataSet2TableAdapters.BorclarTableAdapter();
            this.ogridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ogradDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ogrsydDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ogrkalanborcDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yurtOtomasyonDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borclarBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(183, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Öğrenci İd:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // oogrid
            // 
            this.oogrid.Location = new System.Drawing.Point(262, 48);
            this.oogrid.Name = "oogrid";
            this.oogrid.Size = new System.Drawing.Size(100, 20);
            this.oogrid.TabIndex = 0;
            // 
            // kklnborc
            // 
            this.kklnborc.Location = new System.Drawing.Point(262, 125);
            this.kklnborc.Name = "kklnborc";
            this.kklnborc.Size = new System.Drawing.Size(100, 20);
            this.kklnborc.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(183, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kalan Borc:";
            // 
            // odborc
            // 
            this.odborc.Location = new System.Drawing.Point(262, 89);
            this.odborc.Name = "odborc";
            this.odborc.Size = new System.Drawing.Size(100, 20);
            this.odborc.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(183, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ödenen Borç:";
            // 
            // OdemeAl
            // 
            this.OdemeAl.BackColor = System.Drawing.SystemColors.Info;
            this.OdemeAl.Location = new System.Drawing.Point(215, 172);
            this.OdemeAl.Name = "OdemeAl";
            this.OdemeAl.Size = new System.Drawing.Size(100, 32);
            this.OdemeAl.TabIndex = 5;
            this.OdemeAl.Text = "Ödeme Al";
            this.OdemeAl.UseVisualStyleBackColor = false;
            this.OdemeAl.Click += new System.EventHandler(this.OdemeAl_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ogridDataGridViewTextBoxColumn,
            this.ogradDataGridViewTextBoxColumn,
            this.ogrsydDataGridViewTextBoxColumn,
            this.ogrkalanborcDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.borclarBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(42, 233);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(443, 186);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // yurtOtomasyonDataSet2
            // 
            this.yurtOtomasyonDataSet2.DataSetName = "YurtOtomasyonDataSet2";
            this.yurtOtomasyonDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // borclarBindingSource
            // 
            this.borclarBindingSource.DataMember = "Borclar";
            this.borclarBindingSource.DataSource = this.yurtOtomasyonDataSet2;
            // 
            // borclarTableAdapter
            // 
            this.borclarTableAdapter.ClearBeforeFill = true;
            // 
            // ogridDataGridViewTextBoxColumn
            // 
            this.ogridDataGridViewTextBoxColumn.DataPropertyName = "Ogr_id";
            this.ogridDataGridViewTextBoxColumn.HeaderText = "Ogr_id";
            this.ogridDataGridViewTextBoxColumn.Name = "ogridDataGridViewTextBoxColumn";
            this.ogridDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ogradDataGridViewTextBoxColumn
            // 
            this.ogradDataGridViewTextBoxColumn.DataPropertyName = "Ogr_ad";
            this.ogradDataGridViewTextBoxColumn.HeaderText = "Ogr_ad";
            this.ogradDataGridViewTextBoxColumn.Name = "ogradDataGridViewTextBoxColumn";
            // 
            // ogrsydDataGridViewTextBoxColumn
            // 
            this.ogrsydDataGridViewTextBoxColumn.DataPropertyName = "Ogr_syd";
            this.ogrsydDataGridViewTextBoxColumn.HeaderText = "Ogr_syd";
            this.ogrsydDataGridViewTextBoxColumn.Name = "ogrsydDataGridViewTextBoxColumn";
            // 
            // ogrkalanborcDataGridViewTextBoxColumn
            // 
            this.ogrkalanborcDataGridViewTextBoxColumn.DataPropertyName = "Ogr_kalan_borc";
            this.ogrkalanborcDataGridViewTextBoxColumn.HeaderText = "Ogr_kalan_borc";
            this.ogrkalanborcDataGridViewTextBoxColumn.Name = "ogrkalanborcDataGridViewTextBoxColumn";
            // 
            // odemeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(532, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.OdemeAl);
            this.Controls.Add(this.odborc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.kklnborc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.oogrid);
            this.Controls.Add(this.label1);
            this.Name = "odemeForm";
            this.Text = "Ödeme";
            this.Load += new System.EventHandler(this.odemeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yurtOtomasyonDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borclarBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox oogrid;
        private System.Windows.Forms.TextBox kklnborc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox odborc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button OdemeAl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private YurtOtomasyonDataSet2 yurtOtomasyonDataSet2;
        private System.Windows.Forms.BindingSource borclarBindingSource;
        private YurtOtomasyonDataSet2TableAdapters.BorclarTableAdapter borclarTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogradDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogrsydDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogrkalanborcDataGridViewTextBoxColumn;
    }
}