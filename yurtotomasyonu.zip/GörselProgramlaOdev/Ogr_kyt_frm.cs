﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace yrtotmsyn
{
    public partial class Ogr_kyt_frm : Form
    {
        public Ogr_kyt_frm()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();

        private void Form1_Load(object sender, EventArgs e)
        {
            //bolumler list
         
            SqlCommand komut = new SqlCommand("Select Bolum_ad From Bolum",con.conn());
            komut.Connection = con.conn();
            
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                Ogr_blm.Items.Add(oku[0].ToString());
            }
          con.conn().Close();
            //bos oda list
         
            SqlCommand komut2 = new SqlCommand("Select Oda_no From odalar where Oda_kapasite!=Oda_aktif", con.conn());
            SqlDataReader oku2 = komut2.ExecuteReader();
            while (oku2.Read())
            {
                Oda_no.Items.Add(oku2[0].ToString());
            }
           con.conn().Close();


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Kaydet_Click(object sender, EventArgs e)
        {
            try
            {
             
                SqlCommand cmdkaydet = new SqlCommand("insert into ogrenci(Ogr_ad,Ogr_syd,Tc_no,Telefon_no,Dogum_tarih,Bolum,Mail,Oda_no,Veli_ad_soyad,Veli_telefon_numara,Veli_adres) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11)", con.conn());
                cmdkaydet.Parameters.AddWithValue("@p1", Ogr_ad.Text);
                cmdkaydet.Parameters.AddWithValue("@p2", Ogr_syd.Text);
                cmdkaydet.Parameters.AddWithValue("@p3", Ogr_tc.Text);
                cmdkaydet.Parameters.AddWithValue("@p4", Ogr_tel.Text);
                cmdkaydet.Parameters.AddWithValue("@p5", Ogr_dt.Text);
                cmdkaydet.Parameters.AddWithValue("@p6", Ogr_blm.Text);
                cmdkaydet.Parameters.AddWithValue("@p7", Ogr_mail.Text);
                cmdkaydet.Parameters.AddWithValue("@p8", Oda_no.Text);
                cmdkaydet.Parameters.AddWithValue("@p9", Veli_ad_syd.Text);
                cmdkaydet.Parameters.AddWithValue("@p10", Veli_tel.Text);
                cmdkaydet.Parameters.AddWithValue("@p11", Veli_adrs.Text);

                cmdkaydet.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Kayıt Oluşturuldu");


                //Ogr id label çekme
                SqlCommand kmt = new SqlCommand("select Ogr_id from ogrenci", con.conn());
                 SqlDataReader oku = kmt.ExecuteReader();
                 while (oku.Read())
                 {
                     ogrid.Text = oku[0].ToString();
                 }
                 con.conn().Close();


                //Öğrenci Borç Alanı
                SqlCommand kmtKaydt = new SqlCommand("insert into Borclar(Ogr_ad,Ogr_syd) values(@a2,@a3)", con.conn());
               /*kmtKaydt.Parameters.AddWithValue("@a1", ogrid.Text);*/

                kmtKaydt.Parameters.AddWithValue("@a2", Ogr_ad.Text);
                kmtKaydt.Parameters.AddWithValue("@a3", Ogr_syd.Text);
                kmtKaydt.ExecuteNonQuery();
                con.conn().Close();

            }


            catch (Exception)



            {
                MessageBox.Show("!!!HATA... Lütfen yeniden deneyin");
            }
            ///oda kontenjan azalt
            SqlCommand kmtt = new SqlCommand("update odalar set Oda_aktif=Oda_aktif+1 where Oda_no=@a",con.conn());
            kmtt.Parameters.AddWithValue("@a",Oda_no.Text);

            kmtt.ExecuteNonQuery();
            con.conn().Close();




        }
    }
}
//Data Source=DESKTOP-4788JGO\SQLEXPRESS;Initial Catalog=YurtOtomasyon;Integrated Security=True