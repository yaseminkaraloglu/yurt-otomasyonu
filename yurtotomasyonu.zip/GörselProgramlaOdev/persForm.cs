﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace yrtotmsyn
{
    public partial class persForm : Form
    {
        public persForm()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();
        private void persForm_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet6.Personel' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.personelTableAdapter.Fill(this.yurtOtomasyonDataSet6.Personel);

        }

        private void Kaydet_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("insert into Personel (Personel_ad_soyad,Personel_departman) values(@a,@b) ",con.conn());

            kmt.Parameters.AddWithValue("@a",persad.Text);
            kmt.Parameters.AddWithValue("@b",persgrv.Text);
            kmt.ExecuteNonQuery();

            con.conn().Close();
            MessageBox.Show("Kayıt Eklendi");
            this.personelTableAdapter.Fill(this.yurtOtomasyonDataSet6.Personel);

        }

        private void Sil_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("delete from Personel where Personel_id=@a",con.conn());
            kmt.Parameters.AddWithValue("@a",persid.Text);
            kmt.ExecuteNonQuery();

            con.conn().Close();
            MessageBox.Show("Kayıt Silindi");
            this.personelTableAdapter.Fill(this.yurtOtomasyonDataSet6.Personel);

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int sec;
            string id, ad, grv;
            sec = dataGridView1.SelectedCells[0].RowIndex;
            id = dataGridView1.Rows[sec].Cells[0].Value.ToString();
            ad = dataGridView1.Rows[sec].Cells[1].Value.ToString();
           grv = dataGridView1.Rows[sec].Cells[2].Value.ToString();

            persid.Text = id;
            persad.Text = ad;
            persgrv.Text = grv;
        }

        private void Guncelle_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("update Personel set Personel_ad_soyad=@a,Personel_departman=@b where Personel_id=@w ", con.conn());
            kmt.Parameters.AddWithValue("@a", persad.Text);
            kmt.Parameters.AddWithValue("@b", persgrv.Text);
            kmt.Parameters.AddWithValue("@w", persid.Text);
            kmt.ExecuteNonQuery();

            con.conn().Close();
            MessageBox.Show("Kayıt Güncellendi");
            this.personelTableAdapter.Fill(this.yurtOtomasyonDataSet6.Personel);

        }
    }
}
