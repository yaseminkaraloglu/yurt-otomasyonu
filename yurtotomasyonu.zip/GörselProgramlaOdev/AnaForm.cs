﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace yrtotmsyn
{
    public partial class AnaForm : Form
    {
        public AnaForm()
        {
            InitializeComponent();
        }

        private void AnaForm_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet1.ogrenci' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.ogrenciTableAdapter.Fill(this.yurtOtomasyonDataSet1.ogrenci);
            timer1.Start();
        }

        private void şifreİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sifreIslem go = new sifreIslem();
            go.Show();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongDateString();
            label2.Text = DateTime.Now.ToLongTimeString();



        }

        private void öğrenciEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ogr_kyt_frm go = new Ogr_kyt_frm();
            go.Show();
        }

        private void öğrenciListesiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ogrenciList go = new ogrenciList();
            go.Show();
        }

        private void öğrenciDüzenleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ogrenciList go = new ogrenciList();

            go.Show();
        }

        private void öğrenciÖdemeAlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            odemeForm go = new odemeForm();
            go.Show();

        }

        private void bölümDüzenleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bolumler_frm go = new Bolumler_frm();
            go.Show();

        }

        private void giderEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Giderler go = new Giderler();
            go.Show();

        }

        private void giderListesiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GiderList go = new GiderList();
            go.Show();

        }

        private void personelDüzenleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            persForm go = new persForm();
            go.Show();

        }

        private void çıkışYapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
