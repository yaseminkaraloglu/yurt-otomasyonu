﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace yrtotmsyn
{
    public partial class sifreIslem : Form
    {
        public sifreIslem()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();
        private void sifreIslem_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet5.Admin' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.adminTableAdapter.Fill(this.yurtOtomasyonDataSet5.Admin);

        }

        private void giris_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("insert into Admin (Yonetici_ad,Yonetici_sifre) values (@p1,@p2)",con.conn() );
            kmt.Parameters.AddWithValue("@p1",kullaniciAd.Text);
            kmt.Parameters.AddWithValue("@p2",sifre.Text);
            kmt.ExecuteNonQuery();
            con.conn().Close();
            MessageBox.Show("Yönetici Eklendi");
            this.adminTableAdapter.Fill(this.yurtOtomasyonDataSet5.Admin);

        }

        private void Guncelle_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("update Admin set Yonetici_ad=@a1,Yonetici_sifre=@a2 where Yonetici_id=@a ",con.conn());
            kmt.Parameters.AddWithValue("@a1",kullaniciAd.Text);
            kmt.Parameters.AddWithValue("@a2",sifre.Text);
            kmt.Parameters.AddWithValue("@a",yntcid.Text);
            kmt.ExecuteNonQuery();
            con.conn().Close();
            MessageBox.Show("Güncelleme Başarılı");
            this.adminTableAdapter.Fill(this.yurtOtomasyonDataSet5.Admin);


        }

        private void Sil_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("delete from Admin where Yonetici_id=@a1",con.conn());
            kmt.Parameters.AddWithValue("@a1", yntcid.Text);
            kmt.ExecuteNonQuery();
            con.conn().Close();
            MessageBox.Show("Silme İşlemi Başarılı");
            this.adminTableAdapter.Fill(this.yurtOtomasyonDataSet5.Admin);

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int sec;
            string id,ad, sifr;
            sec = dataGridView1.SelectedCells[0].RowIndex;
            id = dataGridView1.Rows[sec].Cells[0].Value.ToString();
            ad = dataGridView1.Rows[sec].Cells[1].Value.ToString();
            sifr = dataGridView1.Rows[sec].Cells[2].Value.ToString();

            yntcid.Text = id;
            kullaniciAd.Text = ad;
            sifre.Text = sifr;


        }
    }
}
