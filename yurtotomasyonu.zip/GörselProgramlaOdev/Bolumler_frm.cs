﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace yrtotmsyn
{
    public partial class Bolumler_frm : Form
    {
        public Bolumler_frm()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            try
            {
      
                SqlCommand cmd2 = new SqlCommand("update Bolum Set Bolum_ad=@p1 where Bolum_id=@p2", con.conn());
                cmd2.Parameters.AddWithValue("@p2", Bolum_id.Text);
                cmd2.Parameters.AddWithValue("@p1", Bolum_ad.Text);
                cmd2.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Güncelleme Başarılı");
                this.bolumTableAdapter.Fill(this.yurtOtomasyonDataSet.Bolum);
            }
            catch (Exception)
            {

                MessageBox.Show("hata... tekrar deneyin");

            }

        }

        private void Bolumler_frm_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet.Bolum' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.bolumTableAdapter.Fill(this.yurtOtomasyonDataSet.Bolum);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            try
            {
               
                SqlCommand komut1 = new SqlCommand("insert into Bolum (Bolum_ad) values (@p1)", con.conn());
                komut1.Parameters.AddWithValue("@p1", Bolum_ad.Text);
                komut1.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Bölüm Eklendi");

            }
            catch (Exception)
            {

                MessageBox.Show("HATA!!! Yeniden dene");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
           
                SqlCommand cmd2 = new SqlCommand("delete from Bolum where Bolum_id=@p1", con.conn());
                cmd2.Parameters.AddWithValue("@p1", Bolum_id.Text);
                cmd2.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Silme İşlemi Başarılı");
                this.bolumTableAdapter.Fill(this.yurtOtomasyonDataSet.Bolum);

            }
            catch (Exception)
            {

                MessageBox.Show("Hata!!!! Tekrar deneyin");

            }
        }
        int sec;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string id, blm;
            sec = dataGridView1.SelectedCells[0].RowIndex;
            id = dataGridView1.Rows[sec].Cells[0].Value.ToString();
            blm = dataGridView1.Rows[sec].Cells[1].Value.ToString();

            Bolum_id.Text = id;
            Bolum_ad.Text = blm;

        }
    }
}
