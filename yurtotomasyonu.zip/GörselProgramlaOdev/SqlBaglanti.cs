﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace yrtotmsyn
{
    public class SqlBaglanti

    {

        public SqlConnection conn(){
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4788JGO\SQLEXPRESS;Initial Catalog=YurtOtomasyon;Integrated Security=True");
            con.Open();
            return con;
    }


}
}
    

