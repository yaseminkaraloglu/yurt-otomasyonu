﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace yrtotmsyn
{
    public partial class GiderGuncelle : Form
    {
        public GiderGuncelle()
        {
            InitializeComponent();
        }
        SqlBaglanti con = new SqlBaglanti();
        public string id,elektrik, su, dgaz, net, gida, pers, diger;

        private void Güncelle_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand kmt = new SqlCommand("update Gider set Elektrik=@p1,Su=@p2,Dogalgaz=@p3,Internet=@p4,Gıda=@p5,Personel=@p6,Diger=@p7 where Odeme_id=@s1", con.conn());
                kmt.Parameters.AddWithValue("@s1", odmid.Text);

                kmt.Parameters.AddWithValue("@p1", Elektrik.Text);
                kmt.Parameters.AddWithValue("@p2", Su.Text);
                kmt.Parameters.AddWithValue("@p3", Dgaz.Text);
                kmt.Parameters.AddWithValue("@p4", Net.Text);
                kmt.Parameters.AddWithValue("@p5", Gd.Text);
                kmt.Parameters.AddWithValue("@p6", Pers.Text);
                kmt.Parameters.AddWithValue("@p7", Dgr.Text);
                kmt.ExecuteNonQuery();
                con.conn().Close();
                MessageBox.Show("Güncelleme Başarılı");
            }
            catch (Exception)
            {

                MessageBox.Show("Hata!!! Tekrar Deneyiniz");

            }

        }

        private void GiderGüncelle_Load(object sender, EventArgs e)
        {
            odmid.Text = id;
            Elektrik.Text = elektrik;
            Su.Text = su;
            Dgaz.Text = dgaz;
            Pers.Text = pers;
            Net.Text = net;
            Dgr.Text = dgaz;
            Gd.Text = gida;
        }
    }
}
