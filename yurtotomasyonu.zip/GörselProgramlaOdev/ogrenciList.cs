﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace yrtotmsyn
{
    public partial class ogrenciList : Form
    {
        public ogrenciList()
        {
            InitializeComponent();
        }

        private void ogrenciList_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'yurtOtomasyonDataSet3.ogrenci' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.ogrenciTableAdapter.Fill(this.yurtOtomasyonDataSet3.ogrenci);

        }
        int secilen;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            secilen = dataGridView1.SelectedCells[0].RowIndex;
            ogrenciDuzenleForm a = new ogrenciDuzenleForm();
            a.id = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            a.ad = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            a.syd = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            a.tc = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            a.tel = dataGridView1.Rows[secilen].Cells[4].Value.ToString();
            a.dt = dataGridView1.Rows[secilen].Cells[5].Value.ToString();
            a.blm = dataGridView1.Rows[secilen].Cells[6].Value.ToString();
            a.mail = dataGridView1.Rows[secilen].Cells[7].Value.ToString();
            a.odano= dataGridView1.Rows[secilen].Cells[8].Value.ToString();
            a.veliAdSyd = dataGridView1.Rows[secilen].Cells[9].Value.ToString();
            a.veliTel = dataGridView1.Rows[secilen].Cells[10].Value.ToString();
            a.veliAdrs = dataGridView1.Rows[secilen].Cells[11].Value.ToString();

            a.Show();
            this.ogrenciTableAdapter.Fill(this.yurtOtomasyonDataSet3.ogrenci);
        }
    }
}
