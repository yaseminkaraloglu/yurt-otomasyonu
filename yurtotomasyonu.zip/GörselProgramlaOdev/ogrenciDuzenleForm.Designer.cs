﻿
namespace yrtotmsyn
{
    partial class ogrenciDuzenleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Veli_tel = new System.Windows.Forms.MaskedTextBox();
            this.Veli_adrs = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Veli_ad_syd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Oda_no = new System.Windows.Forms.ComboBox();
            this.Ogr_mail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Ogr_blm = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Ogr_dt = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Ogr_tel = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Ogr_syd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Ogr_tc = new System.Windows.Forms.MaskedTextBox();
            this.Ogr_ad = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ogr_id = new System.Windows.Forms.TextBox();
            this.Güncelle = new System.Windows.Forms.Button();
            this.sill = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Öğrenci İd:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 405);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 44;
            this.label11.Text = "Veli Telefon:";
            // 
            // Veli_tel
            // 
            this.Veli_tel.Location = new System.Drawing.Point(123, 398);
            this.Veli_tel.Mask = "(999) 000-0000";
            this.Veli_tel.Name = "Veli_tel";
            this.Veli_tel.Size = new System.Drawing.Size(158, 20);
            this.Veli_tel.TabIndex = 43;
            // 
            // Veli_adrs
            // 
            this.Veli_adrs.Location = new System.Drawing.Point(123, 437);
            this.Veli_adrs.Name = "Veli_adrs";
            this.Veli_adrs.Size = new System.Drawing.Size(158, 20);
            this.Veli_adrs.TabIndex = 42;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 440);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 41;
            this.label9.Text = "Veli Adres:";
            // 
            // Veli_ad_syd
            // 
            this.Veli_ad_syd.Location = new System.Drawing.Point(123, 368);
            this.Veli_ad_syd.Name = "Veli_ad_syd";
            this.Veli_ad_syd.Size = new System.Drawing.Size(158, 20);
            this.Veli_ad_syd.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 371);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 39;
            this.label10.Text = "Veli Ad Soyad:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 336);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 38;
            this.label8.Text = "Oda No:";
            // 
            // Oda_no
            // 
            this.Oda_no.FormattingEnabled = true;
            this.Oda_no.Location = new System.Drawing.Point(123, 333);
            this.Oda_no.Name = "Oda_no";
            this.Oda_no.Size = new System.Drawing.Size(158, 21);
            this.Oda_no.TabIndex = 37;
            // 
            // Ogr_mail
            // 
            this.Ogr_mail.Location = new System.Drawing.Point(123, 290);
            this.Ogr_mail.Name = "Ogr_mail";
            this.Ogr_mail.Size = new System.Drawing.Size(158, 20);
            this.Ogr_mail.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 297);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 35;
            this.label7.Text = "Öğrenci Mail:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Öğrenci Bölüm:";
            // 
            // Ogr_blm
            // 
            this.Ogr_blm.FormattingEnabled = true;
            this.Ogr_blm.Location = new System.Drawing.Point(123, 249);
            this.Ogr_blm.Name = "Ogr_blm";
            this.Ogr_blm.Size = new System.Drawing.Size(158, 21);
            this.Ogr_blm.TabIndex = 33;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "Öğrenci Doğum Tarihi:";
            // 
            // Ogr_dt
            // 
            this.Ogr_dt.Location = new System.Drawing.Point(123, 213);
            this.Ogr_dt.Mask = "00/00/0000";
            this.Ogr_dt.Name = "Ogr_dt";
            this.Ogr_dt.Size = new System.Drawing.Size(159, 20);
            this.Ogr_dt.TabIndex = 31;
            this.Ogr_dt.ValidatingType = typeof(System.DateTime);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Öğrenci Telefon:";
            // 
            // Ogr_tel
            // 
            this.Ogr_tel.Location = new System.Drawing.Point(123, 176);
            this.Ogr_tel.Mask = "(999) 000-0000";
            this.Ogr_tel.Name = "Ogr_tel";
            this.Ogr_tel.Size = new System.Drawing.Size(158, 20);
            this.Ogr_tel.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Öğrenci TC:";
            // 
            // Ogr_syd
            // 
            this.Ogr_syd.Location = new System.Drawing.Point(123, 101);
            this.Ogr_syd.Name = "Ogr_syd";
            this.Ogr_syd.Size = new System.Drawing.Size(158, 20);
            this.Ogr_syd.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "Öğrenci Soyad:";
            // 
            // Ogr_tc
            // 
            this.Ogr_tc.Location = new System.Drawing.Point(123, 137);
            this.Ogr_tc.Mask = "00000000000";
            this.Ogr_tc.Name = "Ogr_tc";
            this.Ogr_tc.Size = new System.Drawing.Size(158, 20);
            this.Ogr_tc.TabIndex = 25;
            this.Ogr_tc.ValidatingType = typeof(int);
            // 
            // Ogr_ad
            // 
            this.Ogr_ad.Location = new System.Drawing.Point(123, 54);
            this.Ogr_ad.Name = "Ogr_ad";
            this.Ogr_ad.Size = new System.Drawing.Size(159, 20);
            this.Ogr_ad.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Öğrenci Ad:";
            // 
            // ogr_id
            // 
            this.ogr_id.Location = new System.Drawing.Point(122, 12);
            this.ogr_id.Name = "ogr_id";
            this.ogr_id.Size = new System.Drawing.Size(159, 20);
            this.ogr_id.TabIndex = 45;
            // 
            // Güncelle
            // 
            this.Güncelle.BackColor = System.Drawing.SystemColors.Info;
            this.Güncelle.Location = new System.Drawing.Point(110, 463);
            this.Güncelle.Name = "Güncelle";
            this.Güncelle.Size = new System.Drawing.Size(91, 31);
            this.Güncelle.TabIndex = 46;
            this.Güncelle.Text = "Güncelle";
            this.Güncelle.UseVisualStyleBackColor = false;
            this.Güncelle.Click += new System.EventHandler(this.Güncelle_Click);
            // 
            // sill
            // 
            this.sill.BackColor = System.Drawing.SystemColors.Info;
            this.sill.Location = new System.Drawing.Point(207, 463);
            this.sill.Name = "sill";
            this.sill.Size = new System.Drawing.Size(91, 31);
            this.sill.TabIndex = 47;
            this.sill.Text = "Sil";
            this.sill.UseVisualStyleBackColor = false;
            this.sill.Click += new System.EventHandler(this.sill_Click);
            // 
            // ogrenciDuzenleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(370, 498);
            this.Controls.Add(this.sill);
            this.Controls.Add(this.Güncelle);
            this.Controls.Add(this.ogr_id);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Veli_tel);
            this.Controls.Add(this.Veli_adrs);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Veli_ad_syd);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Oda_no);
            this.Controls.Add(this.Ogr_mail);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Ogr_blm);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Ogr_dt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Ogr_tel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Ogr_syd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Ogr_tc);
            this.Controls.Add(this.Ogr_ad);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label1);
            this.Name = "ogrenciDuzenleForm";
            this.Text = "Ögrenci Düzenle";
            this.Load += new System.EventHandler(this.ogrenciDuzenleForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox Veli_tel;
        private System.Windows.Forms.TextBox Veli_adrs;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Veli_ad_syd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Oda_no;
        private System.Windows.Forms.TextBox Ogr_mail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Ogr_blm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox Ogr_dt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox Ogr_tel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Ogr_syd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox Ogr_tc;
        private System.Windows.Forms.TextBox Ogr_ad;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox ogr_id;
        private System.Windows.Forms.Button Güncelle;
        private System.Windows.Forms.Button sill;
    }
}